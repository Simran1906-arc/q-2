function isValidPattern(q) {
  if (q.length === 0) return false;

  for (let i = 0; i < q.length; i++) {
    const ch = q[i];

    if (ch === '+') {
      if (i === 0) return false;
      if (q[i - 1] === '+') return false;
    } else if (!/[A-Z]/.test(ch)) {
      return false;
    }
  }

  return true;
}

function regexMatch(p, q) {
  const n = p.length, m = q.length;

  const dp = Array.from({ length: n + 1 }, () =>
    new Array(m + 1).fill(false)
  );

  dp[0][0] = true;

  for (let i = 0; i <= n; i++) {
    for (let j = 1; j <= m; j++) {
      const qc = q[j - 1];

      if (qc === '+') {
        const prev = q[j - 2];

        if (i >= 1 && p[i - 1] === prev) {
          dp[i][j] = dp[i - 1][j - 2] || dp[i - 1][j];
        }
      } else {
        if (i >= 1 && p[i - 1] === qc) {
          dp[i][j] = dp[i - 1][j - 1];
        }
      }
    }
  }

  return dp[n][m];
}

function buildSteps(q) {
  const tokens = [];
  let i = 0;

  while (i < q.length) {
    if (i + 1 < q.length && q[i + 1] === '+') {
      tokens.push({ ch: q[i], plus: true });
      i += 2;
    } else {
      tokens.push({ ch: q[i], plus: false });
      i += 1;
    }
  }

  return tokens;
}

function runMatch() {
  const p = document.getElementById('inputP').value.trim().toUpperCase();
  const q = document.getElementById('inputQ').value.trim().toUpperCase();

  const panel = document.getElementById('resultPanel');
  const badge = document.getElementById('resultBadge');
  const expl = document.getElementById('resultExplanation');
  const steps = document.getElementById('stepsList');

  panel.classList.remove('visible');

  if (!/^[A-Z]+$/.test(p)) {
    show('invalid', 'Invalid Pattern', 'P must contain only uppercase English letters.', []);
    return;
  }

  if (!isValidPattern(q)) {
    show('invalid', 'Invalid Pattern', 'Q has invalid syntax.', []);
    return;
  }

  const result = regexMatch(p, q);
  const tokens = buildSteps(q);

  const explanation = result
    ? `Pattern "${q}" fully matches "${p}".`
    : `Pattern "${q}" does not fully match "${p}".`;

  const chipData = tokens.map(t => ({
    label: t.plus ? `${t.ch}+` : t.ch,
    match: result
  }));

  show(result ? 'true' : 'false',
       result ? 'True' : 'False',
       explanation,
       chipData);
}

function show(type, label, explanation, chips) {
  const panel = document.getElementById('resultPanel');
  const badge = document.getElementById('resultBadge');
  const expl = document.getElementById('resultExplanation');
  const steps = document.getElementById('stepsList');

  badge.className = 'badge ' + type;
  badge.textContent = label;

  expl.textContent = explanation;

  steps.innerHTML = chips.map(c =>
    `<span class="step-chip">${c.label}</span>`
  ).join('');

  panel.classList.add('visible');
}

document.addEventListener('keydown', e => {
  if (e.key === 'Enter') runMatch();
});
